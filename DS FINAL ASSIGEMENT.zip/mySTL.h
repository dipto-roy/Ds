#ifndef mySTL_h
#define mySTL_h
#include <bits/stdc++.h>

//Single Linked list

class Node
{
public:
    int data;
    Node* next;
    Node(int data)
    {
        this->data = data;
        this->next = nullptr;
    }
};

class SingleLinkedList
{
private:
    Node* head;
public:
    SingleLinkedList()
    {
        this->head = nullptr;
    }

    void insertAtLast(int data)
    {
        Node* newNode = new Node(data);
        if (this->head == nullptr)
        {
            this->head = newNode;
            return;
        }
        Node* curr = this->head;
        while (curr->next != nullptr)
        {
            curr = curr->next;
        }
        curr->next = newNode;
    }

    void insertAtFirst(int data)
    {
        Node* newNode = new Node(data);
        newNode->next = this->head;
        this->head = newNode;
    }

    void insertAtAnyPos(int data, int pos)
    {
        Node* newNode = new Node(data);
        if (pos == 0)
        {
            newNode->next = this->head;
            this->head = newNode;
            return;
        }
        Node* curr = this->head;
        for (int i = 0; i < pos-1; i++)
        {
            curr = curr->next;
            if (curr == nullptr)
            {
                throw out_of_range("Position out of range");
            }
        }
        newNode->next = curr->next;
        curr->next = newNode;
    }

    void insertBeforeElement(int data, int target)
    {
        Node* newNode = new Node(data);
        if (this->head == nullptr)
        {
            throw runtime_error("List is empty");
        }
        if (this->head->data == target)
        {
            newNode->next = this->head;
            this->head = newNode;
            return;
        }
        Node* curr = this->head;
        while (curr->next != nullptr && curr->next->data != target)
        {
            curr = curr->next;
        }
        if (curr->next == nullptr)
        {
            throw invalid_argument("Target element not found");
        }
        newNode->next = curr->next;
        curr->next = newNode;
    }

    void deleteElementByValue(int target)
    {
        if (this->head == nullptr)
        {
            throw runtime_error("List is empty");
        }
        if (this->head->data == target)
        {
            this->head = this->head->next;
            return;
        }
        Node* curr = this->head;
        while (curr->next != nullptr && curr->next->data != target)
        {
            curr = curr->next;
        }
        if (curr->next == nullptr)
        {
            throw invalid_argument("Target element not found");
        }
        curr->next = curr->next->next;
    }

    void deleteAtPos(int pos)
    {
        if (this->head == nullptr)
        {
            throw runtime_error("List is empty");
        }
        if (pos == 0)
        {
            this->head = this->head->next;
            return;
        }
        Node* curr = this->head;
        for (int i = 0; i < pos-1; i++)
        {
            curr = curr->next;
            if (curr == nullptr)
            {
                throw out_of_range("Position out of range");
            }
        }
        if (curr->next == nullptr)
        {
            throw out_of_range("Position out of range");
        }
        curr->next = curr->next->next;
    }


    void displayList()
    {
        Node* curr = this->head;
        while (curr != nullptr)
        {
            cout << curr->data << " ";
            curr = curr->next;
        }
        cout << endl;



      //Double Linked List

        class Node
        {
        public:
            int data;
            Node* next;
            Node* prev;
            Node(int data)
            {
                this->data = data;
                this->next = nullptr;
                this->prev = nullptr;
            }
        };

        class DoubleLinkedList
        {
        private:
            Node* head;
            Node* tail;
        public:
            DoubleLinkedList()
            {
                this->head = nullptr;
                this->tail = nullptr;
            }

            void insertAtLast(int data)
            {
                Node* newNode = new Node(data);
                if (this->head == nullptr)
                {
                    this->head = newNode;
                    this->tail = newNode;
                    return;
                }
                newNode->prev = this->tail;
                this->tail->next = newNode;
                this->tail = newNode;
            }

            void insertAtFirst(int data)
            {
                Node* newNode = new Node(data);
                if (this->head == nullptr)
                {
                    this->head = newNode;
                    this->tail = newNode;
                    return;
                }
                newNode->next = this->head;
                this->head->prev = newNode;
                this->head = newNode;
            }

            void insertAtAnyPos(int data, int pos)
            {
                Node* newNode = new Node(data);
                if (pos == 0)
                {
                    newNode->next = this->head;
                    this->head->prev = newNode;
                    this->head = newNode;
                    return;
                }
                Node* curr = this->head;
                for (int i = 0; i < pos-1; i++)
                {
                    curr = curr->next;
                    if (curr == nullptr)
                    {
                        throw out_of_range("Position out of range");
                    }
                }
                newNode->prev = curr;
                newNode->next = curr->next;
                if (curr->next != nullptr)
                {
                    curr->next->prev = newNode;
                }
                else
                {
                    this->tail = newNode;
                }
                curr->next = newNode;
            }

            void insertBeforeElement(int data, int target)
            {
                Node* newNode = new Node(data);
                if (this->head == nullptr)
                {
                    throw runtime_error("List is empty");
                }
                if (this->head->data == target)
                {
                    newNode->next = this->head;
                    this->head->prev = newNode;
                    this->head = newNode;
                    return;
                }
                Node* curr = this->head;
                while (curr->next != nullptr && curr->next->data != target)
                {
                    curr = curr->next;
                }
                if (curr->next == nullptr)
                {
                    throw invalid_argument("Target element not found");
                }
                newNode->prev = curr;
                newNode->next = curr->next;
                curr->next->prev = newNode;
                curr->next = newNode;
            }

            void deleteElement(int data)
            {
                if (this->head == nullptr)
                {
                    throw runtime_error("List is empty");
                }
                if (this->head->data == data)
                {
                    if (this->head->next != nullptr)
                    {
                        this->head->next->prev = nullptr;
                    }
                    else
                    {
                        this->tail = nullptr;
                    }
                    this->head = this->head->next;
                    return;
                }
                if (this->tail->data == data)
                {
                    if (this->tail->prev != nullptr)
                    {
                        this->tail->prev->next = nullptr;
                    }
                    else
                    {
                        this->head = nullptr;
                    }
                    this->tail = this->tail->prev;
                    return;
                }
                Node* curr = this->head;
                while (curr != nullptr && curr->data != data)
                {
                    curr = curr->next;
                }
                if (curr == nullptr)
                {
                    throw invalid_argument("Element not found");
                }
                curr->prev->next = curr->next;
                curr->next->prev = curr->prev;
                delete curr;
            }

            void deletePos(int pos)
            {
                if (this->head == nullptr)
                {
                    throw runtime_error("List is empty");
                }
                if (pos == 0)
                {
                    if (this->head->next != nullptr)
                    {
                        this->head->next->prev = nullptr;
                    }
                    else
                    {
                        this->tail = nullptr;
                    }
                    this->head = this->head->next;
                    return;
                }
                Node* curr = this->head;
                for (int i = 0; i < pos; i++)
                {
                    curr = curr->next;
                    if (curr == nullptr)
                    {
                        throw out_of_range("Position out of range");
                    }
                }
                curr->prev->next = curr->next;
                if (curr->next != nullptr)
                {
                    curr->next->prev = curr->prev;
                }
                else
                {
                    this->tail = curr->prev;
                }
                delete curr;
            }

            void displayList()
            {
                Node* curr = this->head;
                while (curr != nullptr)
                {
                    cout << curr->data << " ";
                    curr = curr->next;
                }
                cout << endl;
            }
        };

        //Stack

        class Stack
{
private:
    struct Node
    {
        int data;
        Node* next;
        Node(int data) : data(data), next(nullptr) {}
    };
    Node* topNode;

public:
    Stack() : topNode(nullptr) {}

    void push(int data)
    {
        Node* newNode = new Node(data);
        if (topNode == nullptr)
        {
            topNode = newNode;
        }
        else
        {
            newNode->next = topNode;
            topNode = newNode;
        }
    }

    void pop()
    {
        if (topNode == nullptr)
        {
            return;
        }
        Node* tempNode = topNode;
        topNode = topNode->next;
        delete tempNode;
    }

    int top() const
    {
        if (topNode == nullptr)
        {
            return -1;  // default value for empty stack
        }
        return topNode->data;
    }





        //Queue

        class Queue
{
private:
    struct Node
    {
        int data;
        Node* next;
        Node(int data) : data(data), next(nullptr) {}
    };
    Node* frontNode;
    Node* rearNode;

public:
    Queue() : frontNode(nullptr), rearNode(nullptr) {}

    void enqueue(int data)
    {
        Node* newNode = new Node(data);
        if (rearNode == nullptr)
        {
            frontNode = rearNode = newNode;
        }
        else
        {
            rearNode->next = newNode;
            rearNode = newNode;
        }
    }

    void dequeue()
    {
        if (frontNode == nullptr)
        {
            return;
        }
        Node* tempNode = frontNode;
        frontNode = frontNode->next;
        if (frontNode == nullptr)
        {
            rearNode = nullptr;
        }
        delete tempNode;
    }

    int front() const
    {
        if (frontNode == nullptr)
        {
            return -1;  // default value for empty queue
        }
        return frontNode->data;
    }

    int rear() const
    {
        if (rearNode == nullptr)
        {
            return -1;  // default value for empty queue
        }
        return rearNode->data;
    }
};


 // Binary Search Tree

 class BST {
private:
    struct Node {
        int data;
        Node* left;
        Node* right;
        Node(int data) : data(data), left(nullptr), right(nullptr) {}
    };
    Node* root;

    Node* insertIntoBSTHelper(Node* node, int data) {
        if (node == nullptr) {
            return new Node(data);
        } else if (data < node->data) {
            node->left = insertIntoBSTHelper(node->left, data);
        } else {
            node->right = insertIntoBSTHelper(node->right, data);
        }
        return node;
    }

    Node* searchInBSTHelper(Node* node, int data) const {
        if (node == nullptr || node->data == data) {
            return node;
        } else if (data < node->data) {
            return searchInBSTHelper(node->left, data);
        } else {
            return searchInBSTHelper(node->right, data);
        }
    }

    void displayInorderHelper(Node* node) const {
        if (node != nullptr) {
            displayInorderHelper(node->left);
            cout << node->data << " ";
            displayInorderHelper(node->right);
        }
    }

    void displayPreorderHelper(Node* node) const {
        if (node != nullptr) {
            cout << node->data << " ";
            displayPreorderHelper(node->left);
            displayPreorderHelper(node->right);
        }
    }

    void displayPostorderHelper(Node* node) const {
        if (node != nullptr) {
            displayPostorderHelper(node->left);
            displayPostorderHelper(node->right);
            cout << node->data << " ";
        }
    }

public:
    BST() : root(nullptr) {}

    void insertIntoBST(int data) {
        root = insertIntoBSTHelper(root, data);
    }

    bool searchInBST(int data) const {
        return searchInBSTHelper(root, data) != nullptr;
    }

    void displayInorder() const {
        displayInorderHelper(root);
        cout << endl;
    }

    void displayPreorder() const {
        displayPreorderHelper(root);
        cout << endl;
    }

    void displayPostorder() const {
        displayPostorderHelper(root);
        cout << endl;
    }
};

#endif // mySTL
