#include "mySTL_h"
#include <bits/stdc++.h>
using namespace std;

int main()
{



    /*

     //SingleLinkedList
    SingleLinkedList myList;

    // Add elements to the list
    myList.insertAtLast(10);
    myList.insertAtLast(20);
    myList.insertAtFirst(5);
    myList.insertAtAnyPos(15, 3);
    myList.insertBeforeElement(25, 20);

    // Display the list
    std::cout << "List: ";
    myList.displayList();
    std::cout << std::endl;

    // Delete elements from the list
    myList.deleteElementByValue(20);
    myList.deleteAtPos(3);

    // Display the updated list
    std::cout << "Updated List: ";
    myList.displayList();
    std::cout << std::endl;



    /*

    //Double Linked List


    DoubleLinkedList list;

    list.insertAtLast(10);
    list.insertAtLast(20);
    list.insertAtLast(30);
    list.insertAtFirst(5);
    list.insertAtAnyPos(15, 3);
    list.insertBeforeElement(25, 30);
    list.displayList();

    list.deleteElement(15);
    list.deletePos(4);
    list.displayList();

    */

    /*
    //stack
    Stack s;

    s.push(10);
    s.push(20);
    s.push(30);

    cout << "Top element: " << s.top() << endl;

    s.pop();
    s.push(40);

    cout << "Top element: " << s.top() << endl;

   */


  //Queue

  Queue q;

    q.enqueue(10);
    q.enqueue(20);
    q.enqueue(30);

    cout << "Front element: " << q.front() << endl;
    cout << "Rear element: " << q.rear() << endl;

    q.dequeue();
    q.enqueue(40);

    cout << "Front element: " << q.front() << endl;
    cout << "Rear element: " << q.rear() << endl;



    /*
   //Binary Search Tree

    BST bst;

    bst.insertIntoBST(50);
    bst.insertIntoBST(30);
    bst.insertIntoBST(20);
    bst.insertIntoBST(40);
    bst.insertIntoBST(70);
    bst.insertIntoBST(60);
    bst.insertIntoBST(80);

    cout << "Inorder traversal: ";
    bst.displayInorder();

    cout << "Preorder traversal: ";
    bst.displayPreorder();

    cout << "Postorder traversal: ";
    bst.displayPostorder();

    int key = 40;
    if (bst.searchInBST(key)) {
        cout << key << " found in BST" << endl;
    } else {
        cout << key << " not found in BST" << endl;
    }

    key = 100;
    if (bst.searchInBST(key)) {
        cout << key << " found in BST" << endl;
    } else {
        cout << key << " not found in BST" << endl;
    }

    */





}
